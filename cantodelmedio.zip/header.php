<header>
        <ul id="menuRedesHeader">
            <li class="iconRedesHeader"><a href="https://www.instagram.com/elcantodelmedio/" target="_blank"><img src="..\wp-content\themes\cantodelmedio\img\mobile\ig-logo.png" class="imgRedesHeader" id="logoInstagramHeader"></a></li>
            <li class="iconRedesHeader"><a href="https://www.youtube.com/channel/UCLtgVMuTefGp63pZiPophPA" target="_blank"><img src="..\wp-content\themes\cantodelmedio\img\mobile\yt-logo-only.png" class="imgRedesHeader" id="logoYoutubeHeader"></a></li>
            <li class="iconRedesHeader"><a href="https://wa.me/5491136148307" target="_blank"><img src="..\wp-content\themes\cantodelmedio\img\mobile\wa-logo.png" class="imgRedesHeader" id="logoWhatsAppHeader"></a></li>
        </ul>

        <button id="burger-menu-toggler">
            <img src="..\wp-content\themes\cantodelmedio\img\mobile\burger-menu.png" id="open-mobile-menu"></img>
            <img src="..\wp-content\themes\cantodelmedio\img\mobile\close-burger-menu.png" id="close-mobile-menu"></img>
        </button>

        <ul id="mainMenu">
            <li class="itemsNav"><a href="..\index.php\#formacionIntegral">Formación integral</a></li>
            <li class="itemsNav"><a href="..\index.php\#consultoriaVoz">Consultorías</a></li>
            <li class="itemsNav"><a href="..\index.php\#asesoriaVoz">Asesorías</a></li>
        </ul>
    </header>